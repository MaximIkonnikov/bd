/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sportclient;
import java.io.FileNotFoundException;
import java.sql.*;
import java.util.Scanner;
import java.util.Vector;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.w3c.dom.Document;
import de.jeckle.RS2DOM.RS2DOM;
import java.io.FileOutputStream;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import sportclient.FileWork;

/**
 *
 * @author DENIM
 */
public class SportClient {
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws ClassNotFoundException, SQLException, InstantiationException, IllegalAccessException, FileNotFoundException, ParseException { 
        // TODO code application logic here    
        Connection connect = null;        
        java.sql.Statement rqst = null; // объект для выполнения SQL запросов
        Scanner sc = new Scanner(System.in); // класс для работы с консолью
        int table_number = 0;    // номер введенной таблицы
        Vector<String> vec_tab = new Vector<String>();
        String temp2 = null;   // временные строковые переменные
        String [] temp3 = null;
        StringBuilder sb = new StringBuilder(); //объект для построения строки
        int menu_select = 0; // переменная = выбранный пункт меню
        int argz;   // входной аргумент для операции INSERT
        int argz3;  // входной аргумент для операции INSERT
        int argz4;  // входной аргумент для операции INSERT
        int cnt_col = 0; //переменная для вывода содержимого таблицы                               
        ResultSet res; // Класс для хранения результатов SQL запроса
        Document doc = null; //Класс для хранения XML 
        // Иницализация драйвера
        Class.forName("org.firebirdsql.jdbc.FBDriver").newInstance();
        //Указание пути к БД
        String strPath = "jdbc:firebirdsql://localhost/C:/SCLUB";
        Class.forName("org.firebirdsql.jdbc.FBDriver").newInstance();
        //Подключение к БД
        connect = DriverManager.getConnection(strPath, "SYSDBA", "masterkey");
        if (connect == null) {
            System.err.println("Невозможно подключиться к БД.");}
        //Создание класса для выполнения SQL запросов
        rqst = connect.createStatement();
        System.out.println("Подключение к БД успешно выполнено.");
        // Получение списка таблиц БД
        DatabaseMetaData metaData = connect.getMetaData();
        ResultSet temp=metaData.getTables(temp2, temp2, temp2, temp3);
        while(temp.next())
	{
            temp2=temp.getString(3);
            if(!temp2.contains("$"))
                vec_tab.add(temp2);
        }

        // Меню
        while (menu_select != 6) {
            // вывод меню
            System.out.println("-------------------------------------------");
            System.out.println("|               SPORT CLUB                |");
            System.out.println("-------------------------------------------");
            System.out.println("Функции:");
            System.out.println("1.Вывод списка всех таблиц");
            System.out.println("2.Добавление записи в таблицу TICKETTYPES");
            System.out.println("3.Выполнение хранимой процедуры DEL_TYPES");
            System.out.println("4.Импорт из JSON данных в ROOMS и SECTIONS");
            System.out.println("5.Экспорт содержимого таблицы в XML");
            System.out.println("6.Выход");
             // считывание номера пункта меню
            System.out.println("Выберите пункт меню:");
            try{
                menu_select = Integer.parseInt(sc.nextLine());
            }catch(NumberFormatException e){
                System.err.println("Ошибка! Вводите только цифры.");
                continue;
            }
             if (menu_select > 6)
                System.err.println("Ошибка! Пункт меню с таким номером отсутствует.");
            
            if (menu_select == 1)
            {               
                System.out.println("Список таблиц:");
                for(int i=1;i<=vec_tab.size();i++)
                {
                    System.out.printf("%d. %s\n",i,vec_tab.elementAt(i-1));
                }
                                System.out.println("Введите номер таблицы для отображения ее содержимого или "
                                        + "\n0 для возврата в основное меню:");
                                try{
                    table_number=Integer.parseInt(sc.nextLine());
                }catch(NumberFormatException e){
                    System.err.println("Ошибка! Номер должен быть числом!");
                    continue;
                }
                if((table_number > vec_tab.size()) || (table_number < 0)){
                    System.err.println("Ошибка! Таблица с таким номером отсутсвует.");
                    continue;
                }
                if(table_number == 0){
                    continue;
                }
                System.out.println();
                //Выполнение SQL запроса
          	    res = rqst.executeQuery("SELECT * from "+ vec_tab.elementAt(table_number-1));                                        
                // Вывод результата
                cnt_col = res.getMetaData().getColumnCount();
                // Вывод содержимого таблицы
                // Сначала имена столбцов:
                for(int i = 1; i < cnt_col + 1; i++){
                    System.out.print(res.getMetaData().getColumnName(i)+
                            "  |  ");
                }
                // Затем сами записи в таблице:
                while(res.next())
                {
                    System.out.println();
                    for (int i = 1;i < cnt_col + 1;i++)
                    {
                            Object obj = res.getObject(i);
                            if (obj!=null)
                            {
                                    System.out.print(obj+"   \t   ");
                            }
                    }
                }
                System.out.println();
                
                    
                continue;
            }
            
            if (menu_select == 2 )
            {
                    if(connect == null) {
                        System.err.println("Соединение с БД не установлено.");
                        continue;
                    }  
                    // ВВОД АРГУМЕНТОВ ДЛЯ ОПЕРАЦИИ INSERT В ТАБЛИЦУ ТИПОВ АБОНЕМЕНТОВ
                    System.out.println("Введите ID типа абонемента:");
                    try{
                    argz=Integer.parseInt(sc.nextLine());
                   }catch(NumberFormatException e){
                    System.err.println("Ошибка! ID не является числом или превышает 9 символов.");
                    continue;
                    }
                    if (argz <= 0)
                    {
                        System.err.println("Ошибка! ID не может быть отрицательным или равным нулю.");
                        continue;
                    }
                    
                    System.out.println("Введите название типа абонемента:");                                
                    String argz2 = sc.nextLine();
                    if (argz2.length()>25 || argz2.isEmpty())
                    {
                        System.err.println("Ошибка! Название типа не может быть пустым или больше 25 символов.");
                        continue;
                    }
                
                    System.out.println("Введите цену:");
                    try{
                    argz3=Integer.parseInt(sc.nextLine());
                    }catch(NumberFormatException e){
                    System.err.println("Ошибка! Цена не является числом или превышает 9 символов.");
                    continue;
                    }
                    if (argz3<=0)
                    {
                        System.err.println("Ошибка! Цена не может быть отрицательной или равна 0.");
                        continue;
                    }
                    
                    try{                             
                    rqst.executeUpdate("insert into TICKETTYPES values ('"+argz+"','"+argz2+"','"+argz3+"');");
                    System.out.println("Запись добавлена в таблицу.");
                    }catch (SQLException se){
                    System.out.println(se.getMessage());
                    }
                    
                    continue;
            }
            
            if (menu_select == 3)
            {
                    if(connect == null) {
                        System.err.println("Соединение с БД не установлено.");
                        continue;
                    }
                    System.out.println("Хранимая процедура DEL_TYPES удаляет неиспользуемые типы абонементов \n");
                    PreparedStatement pstmt = connect.prepareStatement("{call DEL_TYPES}");
                    pstmt.execute();
                    System.out.println("\nХранимая процедура DEL_TYPES выполнена.");
                    pstmt.close();
                    continue;
                    
            }
            if (menu_select == 4)
            {
              
                JSONParser parser = new JSONParser(); //создание объекта для парсинга
                String textjson = FileWork.read("C://JSON/rooms.json");
                Object obj = parser.parse(textjson);
                JSONObject jsonObj = (JSONObject) obj;                
                JSONArray jo = (JSONArray) jsonObj.get("Rooms");
                
                //Добавление данных в таблицу ROOMS
                for (int i = 0; i<jo.size();i++){
                JSONObject element = (JSONObject) jo.get(i);
                try{
                rqst.executeUpdate("insert into ROOMS values ('"+element.get("ID_ROOM")+"','"+element.get("ROOMNAME")+"');");
                }catch (SQLException se){
                System.out.println(se.getMessage());
                }
                }
                //Добавление данных в таблицу SECTIONS
                textjson = FileWork.read("C://JSON/sections.json");
                obj = parser.parse(textjson);
                jsonObj = (JSONObject) obj;                
                jo = (JSONArray) jsonObj.get("Sections");
                
                for (int i=0; i<jo.size();i++){
                    JSONObject element = (JSONObject) jo.get(i);
                    try{
                    rqst.executeUpdate("insert into SECTIONS values ('"+element.get("ID_SECTION")+"','"+element.get("SECTIONNAME")+"','"+element.get("ID_ROOM")+"');");
                    }catch (SQLException se){
                    System.out.println(se.getMessage());
                    }
                    }
                
                System.out.println("\nИмпорт данных из JSON файлов в таблицы ROOMS и SECTIONS выполнен.");
                
                continue;
                
                
            }
            if (menu_select ==5)
            {
             System.out.println("Список таблиц:");
                for(int i=1;i<=vec_tab.size();i++)
                {
                    System.out.printf("%d. %s\n",i,vec_tab.elementAt(i-1));
                }
                                System.out.println("Введите номер таблицы для экспорта в XML:");
                                try{
                    table_number=Integer.parseInt(sc.nextLine());
                }catch(NumberFormatException e){
                    System.err.println("Ошибка! Номер должен быть числом!");
                    continue;
                }
                if((table_number > vec_tab.size()) || (table_number < 0)){
                    System.err.println("Ошибка! Таблица с таким номером отсутсвует.");
                    continue;
                }
                if(table_number == 0){
                    continue;
                }
                System.out.println();
                //Выполнение SQL запроса
          	    res = rqst.executeQuery("SELECT * from "+ vec_tab.elementAt(table_number-1));                                        
                
                 Document xsd = RS2DOM.ResultSet2XSDDOM(res);
                 Document d = RS2DOM.ResultSet2DOM(res);
                    try {
				Transformer myTransformer =
					(TransformerFactory.newInstance()).newTransformer();
				System.out.println(
					"Схема, описывающая XML, экспортирована в файл Description.xml");
				myTransformer.transform(
					new DOMSource(xsd),
					new StreamResult(new FileOutputStream("C://Description.xml")));
                                System.out.println(
					"\n\nСодержимое таблицы экспортировано в XML файл Data.xml");
				myTransformer.transform(
					new DOMSource(d),
					new StreamResult(new FileOutputStream("C://Data.xml")));
			} catch (Exception e) {
				e.printStackTrace();
			}
             continue;       
            }
            if (menu_select == 6)
            {
                    System.out.println("ББ");
                    continue;
            }
        }
       System.exit(0);
    }
   
    
    
}
